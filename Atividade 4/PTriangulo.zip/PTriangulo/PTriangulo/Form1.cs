﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        private void txtbxLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxLado2.Text, out lado2))
            {
                MessageBox.Show("Valor inválido");
                txtbxLado2.Focus();
            }
            else
            {
                if (lado2 <= 0)
                {
                    MessageBox.Show("Valor inválido!");
                    txtbxLado2.Focus();
                }
            }
        }

        private void txtbxLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxLado3.Text, out lado3))
            {
                MessageBox.Show("Valor inválido");
                txtbxLado3.Focus();
            }
            else
            {
                if (lado3 <= 0)
                {
                    MessageBox.Show("Valor inválido!");
                    txtbxLado3.Focus();
                }
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((lado1 < lado2 + lado3) && (lado1 > Math.Abs(lado2 - lado3)) && 
                (lado2 < lado1 + lado3) && (lado2 > Math.Abs(lado2 - lado3)) &&
                (lado3 < lado1 + lado2) && (lado3 > Math.Abs(lado1 - lado2)))
                {
                if (lado1 == lado2 && lado2 == lado3)
                {
                    MessageBox.Show("É triângulo equilátero");
                }
                else if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3)
                {
                    MessageBox.Show("É triângulo Escaleno");
                }
                else
                {
                    MessageBox.Show("É triângulo Isóceles");
                }

            }
            else
            {
                MessageBox.Show("Não é triângulo");
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtbxLado1.Clear();
            txtbxLado2.Clear();
            txtbxLado3.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtbxLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxLado1.Text, out lado1))
            {
                MessageBox.Show("Valor inválido");
                txtbxLado1.Focus();
            }
            else
            {
                if (lado1 <= 0)
                {
                    MessageBox.Show("Valor inválido!");
                    txtbxLado1.Focus();
                }
            }
        }
    }
}
