﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio; //criando as variaveis globlal
        Double altura;
        Double volume; 
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtRaio.Text, out raio))//convertendo o texto digitado no raio no tipo double 
            {
                MessageBox.Show("Raio Inválido");
                txtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Focus();
                }
            }
        }

        private void txtAltura_Validating(object sender, CancelEventArgs e) //
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                e.Cancel = true; //cancel e focus é a mesma coisa
            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    e.Cancel = true;
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;// COISA DE PROVA: enabled = false é so leitura e nao deixa nem ir na caixa; o readonly= true ainda deixa passar por ali 
            txtVolume.Text = volume.ToString("N2");//esse N2 é pras casas decimais
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //limpar os dados, todos fazem a mesma coisa
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;
            //se quiser que volte pro raio no final da um txtRaio.Focus()
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
