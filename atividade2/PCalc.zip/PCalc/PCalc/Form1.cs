﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //variaveis globais

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                numero2 = Convert.ToDouble(txtNum2.Text); //convertendo pra double
            }
            catch (Exception ex) //pra n quebrar a aplicacao usa catch ou tryparse
            {
                //MessageBox.Show("Número Inválido"); //se der errado aparece a mensagem
                errorProvider2.SetError(txtNum2, "Número 2 inválido");
                txtNum2.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1+ numero2; //soma
            txtResul.Text= resultado.ToString(""); 
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2; //subtrai
            txtResul.Text = resultado.ToString("");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2; //multiplica
            txtResul.Text = resultado.ToString("");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Divisão por zero", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);//esse mboxbutton é a mensagem q vc pode clicar quando da erro
                txtNum2.Text = ""; //limpando
                txtNum1.Focus();
            }
            else
            {
                resultado = numero1 / numero2; //divide
                txtResul.Text = resultado.ToString("");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResul.Text = "";

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1)) //convertendo e se der certo joga pra variavel depois do out
            {
                //MessageBox.Show("Número Inválido"); //como tem a ! antes do double isso aqui aparece se der errado
                errorProvider1.SetError(txtNum1, "Número 1 inválido");
                txtNum1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNum1, "");
            }
        }
    }
}
