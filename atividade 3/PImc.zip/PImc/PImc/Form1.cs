﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {

        Double altura, peso, imc;
        

        private void mskdbxAltura_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(mskdbxAltura.Text, out altura)) || (altura <= 0))
            {
                MessageBox.Show("Numero Inválido");
                Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            imc= Math.Round(imc,1);
            txtImc.Text = imc.ToString();

            if (imc < 18.5)
                {
                    MessageBox.Show("Magreza");
                }
                else if (imc <= 24.9)
                {
                    MessageBox.Show("Normal");
                }
                else if (imc <= 29.9)
                {
                    MessageBox.Show("Sobrepeso");
                }
                else if (imc <= 39.9)
                {
                    MessageBox.Show("Obesidade");
                }
            else
            {
                MessageBox.Show("Obesidade Grave");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdbxAltura.Text = string.Empty;
            mskdbxPeso.Text = string.Empty;
            txtImc.Text = string.Empty;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskdbxPeso_Validated(object sender, EventArgs e)
        {
            if((!Double.TryParse(mskdbxPeso.Text, out peso))||(peso<=0))
            {
                MessageBox.Show("Numero Inválido");
                Focus();
            }
        }
    }
}
