﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string compara;
            int[,] respostas = new int[8,10];
            char[] gabarito = new char[10]{ 'A', 'B', 'C', 'D','E','B','B','C','A','E'};
            for (int alunos = 0; alunos < 8; alunos++)
            {
                for (int questoes = 0; questoes < 10; questoes++) { }
                compara = Interaction.InputBox("Gabarito", "Digite suas respostas: ");
                
            }
        }
    }
}
