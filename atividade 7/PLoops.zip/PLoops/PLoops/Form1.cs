namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exerc�cio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio1 objExercicio1 = new frmExercicio1();
            objExercicio1.Show();
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 objExercicio2 = new frmExercicio2();
            objExercicio2.Show();
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 objExercicio3 = new frmExercicio3();
            objExercicio3.Show();
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 objExercicio4 = new frmExercicio4();
            objExercicio4.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
