﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            double H = 0;
            int N=0;
     
            if (int.TryParse(txtNumeroN.Text, out N) && N >0)
            { 
              for (int i=1; i <= N; i++)
                {
                    H += 1 / (double)i;
                }

                MessageBox.Show("O número H é "+ H);
            }else {
                MessageBox.Show("N precisa ser maior que 1");
            }
        }
    }
}
