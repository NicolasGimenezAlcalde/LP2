﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumeroN = new TextBox();
            btnNumeroH = new Button();
            lbl1 = new Label();
            SuspendLayout();
            // 
            // txtNumeroN
            // 
            txtNumeroN.Location = new Point(336, 205);
            txtNumeroN.Name = "txtNumeroN";
            txtNumeroN.Size = new Size(322, 23);
            txtNumeroN.TabIndex = 0;
            // 
            // btnNumeroH
            // 
            btnNumeroH.Font = new Font("Segoe UI", 20F);
            btnNumeroH.Location = new Point(336, 300);
            btnNumeroH.Name = "btnNumeroH";
            btnNumeroH.Size = new Size(297, 119);
            btnNumeroH.TabIndex = 1;
            btnNumeroH.Text = "Gerar o número H";
            btnNumeroH.UseVisualStyleBackColor = true;
            btnNumeroH.Click += btnNumeroH_Click;
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Font = new Font("Segoe UI", 15F);
            lbl1.Location = new Point(224, 200);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(106, 28);
            lbl1.TabIndex = 2;
            lbl1.Text = "Digite o N:";
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1053, 598);
            Controls.Add(lbl1);
            Controls.Add(btnNumeroH);
            Controls.Add(txtNumeroN);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumeroN;
        private Button btnNumeroH;
        private Label lbl1;
    }
}