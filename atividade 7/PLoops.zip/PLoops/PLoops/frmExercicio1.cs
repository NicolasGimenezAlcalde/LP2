﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int branco = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (rchtxtFrase.Text[i] == ' ')
                {
                    branco += 1;
                }
            }
            MessageBox.Show("Tem " + branco + " espaços em branco");

        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int i = 0, contaletraR = 0;
            while (i < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[i] == 'R' || rchtxtFrase.Text[i] == 'r')
                {
                    contaletraR += 1;
                }
                i++;
            }
            MessageBox.Show("Tem " + contaletraR + " letras R");
        }

        private void btnDuplicada_Click(object sender, EventArgs e)
        {
            int i=0, contaPares = 0;
            do
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1])
                {
                    contaPares += 1;
                }
                i++;
            }
            while (i < rchtxtFrase.Text.Length - 1);
            MessageBox.Show("Tem " +contaPares+ " pares de letras iguais");
        }
    }
}
