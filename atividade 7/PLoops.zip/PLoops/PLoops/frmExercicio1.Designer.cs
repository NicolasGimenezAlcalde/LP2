﻿namespace PLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnBranco = new Button();
            btnR = new Button();
            btnDuplicada = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(389, 83);
            rchtxtFrase.MaxLength = 100;
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(484, 218);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnBranco
            // 
            btnBranco.Font = new Font("Segoe UI", 20F);
            btnBranco.Location = new Point(43, 382);
            btnBranco.Name = "btnBranco";
            btnBranco.Size = new Size(378, 155);
            btnBranco.TabIndex = 1;
            btnBranco.Text = "Quantidade de espaços em branco na frase";
            btnBranco.UseVisualStyleBackColor = true;
            btnBranco.Click += btnBranco_Click;
            // 
            // btnR
            // 
            btnR.Font = new Font("Segoe UI", 20F);
            btnR.Location = new Point(457, 382);
            btnR.Name = "btnR";
            btnR.Size = new Size(378, 155);
            btnR.TabIndex = 2;
            btnR.Text = "Quantidade de letras \"R\" na frase";
            btnR.UseVisualStyleBackColor = true;
            btnR.Click += btnR_Click;
            // 
            // btnDuplicada
            // 
            btnDuplicada.Font = new Font("Segoe UI", 20F);
            btnDuplicada.Location = new Point(869, 382);
            btnDuplicada.Name = "btnDuplicada";
            btnDuplicada.Size = new Size(378, 155);
            btnDuplicada.TabIndex = 3;
            btnDuplicada.Text = "Quantidade de pares de letras iguais na frase";
            btnDuplicada.UseVisualStyleBackColor = true;
            btnDuplicada.Click += btnDuplicada_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1322, 648);
            Controls.Add(btnDuplicada);
            Controls.Add(btnR);
            Controls.Add(btnBranco);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnBranco;
        private Button btnR;
        private Button btnDuplicada;
    }
}